Android fetching device location using Fused Location API

[Tutorial](https://www.androidhive.info/2012/07/android-gps-location-manager-tutorial/)

[Apk](http://download.androidhive.info/apk/android-location.apk)

![Android Fetching User Location](https://www.androidhive.info/wp-content/uploads/2018/05/android-location-update-using-google-fused-api.png)